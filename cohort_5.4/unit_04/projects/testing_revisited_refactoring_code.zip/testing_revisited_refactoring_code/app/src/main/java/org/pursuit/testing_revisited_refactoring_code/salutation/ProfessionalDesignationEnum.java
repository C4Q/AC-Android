package org.pursuit.testing_revisited_refactoring_code.salutation;

public enum ProfessionalDesignationEnum {

    MEDICAL_DOCTOR,
    LAWYER,
    JUDGE,
    ACADEMIC_PROFESSONAL,
    DENTIST,
    CERTIFIED_PUBLIC_ACCOUNTANT,
    VETERNARIAN
}
